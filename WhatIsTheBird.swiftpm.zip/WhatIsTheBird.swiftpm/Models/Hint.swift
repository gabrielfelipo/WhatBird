//
//  File.swift
//  
//
//  Created by gabrielfelipo on 19/04/23.
//

import Foundation
import SwiftUI

struct Hint {
    let image: Image
    let text: Text
}
