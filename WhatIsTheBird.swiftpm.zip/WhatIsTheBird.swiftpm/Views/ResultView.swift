//
//  SwiftUIView.swift
//  
//
//  Created by gabrielfelipo on 19/04/23.
//

import SwiftUI

struct ResultView: View {
    let correct: Bool
    
    var body: some View {
        VStack{
            
            Spacer().frame(height: 32)
            
            HStack{
                Spacer().frame(width: 32)
                Spacer()
                
                let firstText = Text("The ")
                    .font(.system(size: 40, weight: .bold))
                    .foregroundColor(.white)
                let secondText = Text("secret bird ")
                    .font(.system(size: 40, weight: .bold))
                    .foregroundColor(.purple)
                let thirdText = Text("was the ")
                    .font(.system(size: 40, weight: .bold))
                    .foregroundColor(.white)
                let fourthText = Text("Kakapo")
                    .font(.system(size: 40, weight: .bold))
                    .foregroundColor(.green)
                
                if correct == true {
                    let zeroText = Text("Congratulations! ")
                        .font(.system(size: 40, weight: .bold))
                        .foregroundColor(.green)
                    
                    zeroText+firstText+secondText+thirdText+fourthText
                }else{
                    firstText+secondText+thirdText+fourthText
                }
                
                Spacer()
                Spacer().frame(width: 32)
            }
            
            Spacer()
        }
        .frame(maxWidth: .infinity)
        .background(LinearGradient(colors: [.black,.clear], startPoint: .top, endPoint: .center).opacity(0.8))
        .background(
            Image("Result")
                .resizable()
                .edgesIgnoringSafeArea(.all)
                .aspectRatio(contentMode: .fill)
        )
    }
}

struct ResultView_Previews: PreviewProvider {
    static var previews: some View {
        ResultView(correct: true)
            .previewInterfaceOrientation(.landscapeRight)
    }
}
